<?php
    $conn = new mysqli('localhost', 'root', '', 'library')
    
?>