<!-- <?php

 
$bookName = '';
$bookName = isset($_POST['bookName']) ? htmlspecialchars($_POST['bookName']) : " ";
 
if (!empty($bookName)) {

    $sanitized_book_name = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $bookName);
     
 
    if (isset($_COOKIE[$sanitized_book_name])) {
        echo "Book is not available";
    } else {
        echo "Book is available";
    }
} else {
    echo "Invalid book name";
}
 



?> -->

<?php
// Database connection
$conn = mysqli_connect("localhost", "root", "", "library");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the form data
    $bookName = mysqli_real_escape_string($conn, $_POST['bookName']);
    $isbnNumber = mysqli_real_escape_string($conn, $_POST['isbnNumber']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);

    // Insert the book into the database (id is auto-incremented)
    $sql = "INSERT INTO book (title, isbn, category) 
            VALUES ('$bookName', '$isbnNumber', '$category')";

    if (mysqli_query($conn, $sql)) {
        echo "<p>Book added successfully!</p>";

        // Fetch the recently added book details
        $lastInsertedId = mysqli_insert_id($conn);
        $fetchSql = "SELECT id, title, isbn, category FROM book WHERE id = $lastInsertedId";
        $result = mysqli_query($conn, $fetchSql);

        if (mysqli_num_rows($result) > 0) {
            echo "<h3>Recently Added Book</h3>";
            echo "<table border='1' cellpadding='10' cellspacing='0'>";
            echo "<tr><th>ID</th><th>Title</th><th>ISBN</th><th>Category</th></tr>";

            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                echo "<td>" . htmlspecialchars($row['title']) . "</td>";
                echo "<td>" . htmlspecialchars($row['isbn']) . "</td>";
                echo "<td>" . htmlspecialchars($row['category']) . "</td>";
                echo "</tr>";
            }

            echo "</table>";
        } else {
            echo "<p>Error fetching book details.</p>";
        }
    } else {
        echo "<p>Error: " . mysqli_error($conn) . "</p>";
    }
}

mysqli_close($conn);
?>






