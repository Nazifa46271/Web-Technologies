<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $isValid = true; // Flag for validation status

    // Validate userName: should only contain letters and spaces
    if (preg_match("/^[a-zA-Z\s]+$/", $_POST['userName'])) {
        $userName = htmlspecialchars(trim($_POST['userName']));
    } else {
        echo "<p><strong>Error: User name must contain only letters and spaces.</strong></p>";
        $isValid = false;
    }

    // Validate userId: format XX-XXXXX-X
    if (preg_match("/^[0-9]{2}-[0-9]{5}-[1-3]$/", $_POST['userId'])) {
        $userId = htmlspecialchars($_POST['userId']);
    } else {
        echo "<p><strong>Error: User ID must be in the format XX-XXXXX-X.</strong></p>";
        $isValid = false;
    }

    // Validate borrowDate and returnDate
    if (!empty($_POST['borrowDate']) && !empty($_POST['returnDate'])) {
        $borrowDate = htmlspecialchars($_POST['borrowDate']);
        $returnDate = htmlspecialchars($_POST['returnDate']);
        
        $borrowTimestamp = strtotime($borrowDate);
        $returnTimestamp = strtotime($returnDate);

        $daysDiff = ($returnTimestamp - $borrowTimestamp) / (60 * 60 * 24);
        if ($daysDiff < 0) {
            echo "<p><strong>Error: Return date must not be earlier than borrow date.</strong></p>";
            $isValid = false;
        } elseif ($daysDiff > 10) {
            echo "<p><strong>Error: The borrowing period must not exceed 10 days.</strong></p>";
            $isValid = false;
        }
    } else {
        echo "<p><strong>Error: Both borrow date and return date are required.</strong></p>";
        $isValid = false;
    }

    // Validate book title
    if (!empty($_POST['bookName'])) {
        $bookName = htmlspecialchars($_POST['bookName']);
    } else {
        echo "<p><strong>Error: Book title is required.</strong></p>";
        $isValid = false;
    }

    // Validate token number
    if (isset($_POST['tokenNumber']) && is_numeric($_POST['tokenNumber'])) {
        $tokenNumber = intval($_POST['tokenNumber']);
    } else {
        echo "<p><strong>Error: Token number must be a valid number.</strong></p>";
        $isValid = false;
    }

    // Validate fee
    if (isset($_POST['fees']) && is_numeric($_POST['fees'])) {
        $fees = number_format((float)$_POST['fees'], 2, '.', '');
    } else {
        echo "<p><strong>Error: Fee must be a valid numeric value.</strong></p>";
        $isValid = false;
    }

    // Validate payment status
    if (!empty($_POST['payment']) && ($_POST['payment'] === 'Yes' || $_POST['payment'] === 'No')) {
        $paymentStatus = htmlspecialchars($_POST['payment']);
    } else {
        echo "<p><strong>Error: Payment status must be 'Yes' or 'No'.</strong></p>";
        $isValid = false;
    }

    // Check validation status
    if ($isValid) {
        // Sanitize book name for cookie
        $sanitizedBookName = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $bookName);

        if (isset($_COOKIE[$sanitizedBookName])) {
            echo "<p><strong>Error: Book is currently not available.</strong></p>";
        } else {
            // Set cookie for book borrowing
            setcookie($sanitizedBookName, $userName, time() + 120); // Cookie valid for 2 minutes
            echo "<p><strong>Book Borrowed Successfully!</strong></p>";
            echo "<p>Details:</p>";
            echo "<ul>";
            echo "<li><strong>Name:</strong> $userName</li>";
            echo "<li><strong>ID:</strong> $userId</li>";
            echo "<li><strong>Borrow Date:</strong> $borrowDate</li>";
            echo "<li><strong>Return Date:</strong> $returnDate</li>";
            echo "<li><strong>Book Title:</strong> $bookName</li>";
            echo "<li><strong>Token Number:</strong> $tokenNumber</li>";
            echo "<li><strong>Fee:</strong> $$fees</li>";
            echo "<li><strong>Payment Status:</strong> $paymentStatus</li>";
            echo "</ul>";
        }
    } else {
        echo "<p><strong>Error: Borrowing process failed due to validation errors.</strong></p>";
    }
}
?>
